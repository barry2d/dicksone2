from http import client
from urllib import response
from django.test import TestCase, Client
from django.urls import reverse
import json
from order.models import Order, OrderItem

class TestView(TestCase):
    def setUp(self):
        self.client=Client()
        self.order_list_url=reverse('order_list')
        
        
    def test_order_list_GET(self):
        response=client.get(self.order_list_url)
        
        self.assertEquals(response.status_code,200)

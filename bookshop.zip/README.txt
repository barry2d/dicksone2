please used vs code:
download vs code first then you follow the following steps
1 create virtual environment using the following commands 
pip install pipenv
 then lauch that virtual environment using the following commands
pipenv shell
then migrate forward to bookshop location using, cd desktop then cd bookshop,,, this depent if you the folder is on desktop
thhen install django by using 
pipenv install django
then run the server by:
python manage.py runserver
Then copy the url and paste on chrome

To open terminal while on vs code you click ctr+`